Placeholder for 501c3 determination letter - please upload actual IRS document
